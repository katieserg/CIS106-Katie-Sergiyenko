f = open("data.txt", "r")

name = f.readline()
tuition_sum = 0
students = 0

while name != "":
  code = f.readline()
  credits = f.readline()
  
  if str(code) == "I":
    cost_per_credit = 250.00
  else:
    cost_per_credit = 500.00
  
  tuition_owed = int(credits)*cost_per_credit

  print(str(name) + "Credits taken: " + str(credits) + "  Tuition owed: $" + str(tuition_owed))
  tuition_sum = tuition_sum + tuition_owed
  students = students + 1

  name = f.readline()

print("Sum of all tuition owed: $" + str(tuition_sum))
print("Number of students: " + str(students))