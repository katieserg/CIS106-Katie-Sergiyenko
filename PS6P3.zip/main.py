f = open("data1.txt", "r")

name = f.readline()
bonus_sum = 0

while name != "":
  salary = f.readline()
  if float(salary) >= 100000.00:
    bonus_rate = 0.20
  elif float(salary) == 50000.00:
    bonus_rate = 0.15
  else:
    bonus_rate = 0.10
  
  bonus = bonus_rate * float(salary)

  bonus_sum = bonus_sum + bonus

  print(str(name) + "Salary: $" + str(salary) + "  Bonus: $" + str(bonus))

  name = f.readline()

print("Sum of all bonuses: $" + str(bonus_sum))