def hilow(lastn,score):
  l = len(lastn)
  hiscore = -1.0
  lowscore = 999.99
  for y in range (0,l,1):
    if float(score[y]) > float(hiscore):
      hiindex = y
      hiscore = score[y]
    
    if float(score[y]) < float(lowscore):
      lowindex = y
      lowscore = score[y]
  
  print("Highest Exam Score: ", lastn[hiindex], score[hiindex])
  print("Lowest Exam Score: ", lastn[lowindex], score[lowindex])
def average(score):
  sum = 0
  for t in score:
    sum = sum + t
  avg = sum/len(score)
  return avg

f = open("file.txt", "r")

lastname = f.readline()
lastn = []
score = []

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()
f.close()

average(score)
avg = average(score)

hilow(lastn,score)
print("Average Exam Score:", avg)