def displaynames(lastn,score):
  print("Last Names and Exam Scores")
  l = len(lastn)
  for y in range(0,l,1):
    print(lastn[y], score[y])
def displayr(lastn,score):
  print("Reverse Order")
  l = len(lastn)
  for y in range(l-1,-1,-1):
    print(lastn[y], score[y])
def displaya(lastn,score):
  print("Ascending Order")
  l = len(lastn)
  lastn.sort(reverse = False)
  score.sort(reverse = False)
  for y in range(0,l,1):
    print(lastn[y], score[y])
  
f = open("lastn.txt", "r")
lastn = []
score = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()
f.close()

displaynames(lastn,score)
displayr(lastn,score)
displaya(lastn,score)