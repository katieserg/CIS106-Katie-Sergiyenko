f = open("data.txt", "r")

item = f.readline()
sum = 0
count = 0

while item != "":
  quantity = f.readline()
  price = f.readline()

  extended_price = float(quantity) * float(price)

  print(str(item) + "Quantity :" + str(quantity) + "  Price: $" + str(price) + "  Extended Price: $" + str(extended_price))

  sum = sum + extended_price
  count = count + 1

  average_q = float(quantity)/5
  average_p = float(price)/5

  item = f.readline()

avg_order = sum/count
print("Sum of all extended prices: $" + str(sum))
print("Number of orders: " + str(count))
print("Average order: $" + str(avg_order))