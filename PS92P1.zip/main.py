def displaynames(lastn):
  print("Last Names")
  for c in lastn:
    print(c)
def displayr(lastn):
  print("Names in Reverse Order")
  l = len(lastn)
  for y in range(l-1,-1,-1):
    print(lastn[y])
def displaya(lastn):
  print("Names in Ascending Order")
  l = len(lastn)
  lastn.sort(reverse = False)
  for y in range(0,l,1):
    print(lastn[y])

f = open("lastn.txt", "r")
lastn = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  lastname = f.readline()
f.close()

displaynames(lastn)
displayr(lastn)
displaya(lastn)