def display(lastn, batavg):
  print("Last Names and Batting Averages")
  l = len(lastn)
  for y in range(0,l,1):
    print(lastn[y], batavg[y])
def search(lastn, name):
  l = len(lastn)
  i = -1
  for y in range(0,l,1):
    if lastn[y] == name:
      i = y
  return i

f = open("file.txt", "r")
lastn = []
batavg = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  batavg.append(s)
  lastname = f.readline()
f.close()

display(lastn, batavg)

name = str(input("Enter a last name: "))
while name != "":
  i = search(lastn,name)
  print(lastn[i], "Batting Average: ", batavg[i])
  name = str(input("Enter another last name: "))